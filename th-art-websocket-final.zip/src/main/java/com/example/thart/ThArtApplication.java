package com.example.thart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThArtApplication {
    public static void main(String[] args) {
        SpringApplication.run(ThArtApplication.class, args);
    }
}