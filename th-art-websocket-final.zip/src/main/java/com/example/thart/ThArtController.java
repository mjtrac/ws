package com.example.thart;

import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ThArtController {
    private int yOffset = 20;
    private String currentWord = "";
    private boolean justEntered = false;

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @MessageMapping("/move")
    @SendTo("/topic/position")
    public Integer move(String direction) {
        if ("up".equals(direction) && yOffset > 0) yOffset--;
        if ("down".equals(direction) && yOffset < 40) yOffset++;
        return yOffset;
    }

    @MessageMapping("/type")
    @SendTo("/topic/typed")
    public String type(String key) {
        if ("\n".equals(key)) {
            justEntered = true;
            String toSend = currentWord;
            currentWord = "";
            return "\n" + toSend;
        } else if (key.matches("[a-zA-Z0-9 ]")) {
            if (justEntered) {
                currentWord = key;
                justEntered = false;
            } else {
                currentWord += key;
            }
            return currentWord;
        } else {
            return currentWord;
        }
    }
}